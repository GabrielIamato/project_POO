/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

/**
 *
 * @author thiag
 */
public class GerenciadorDeFases {
    private Fase[] fases;
    private int faseAtual;
    
    public GerenciadorDeFases() {
        fases = new Fase[5]; 
        fases[0] = new Fase1();
        fases[1] = new Fase2();
        faseAtual = 0;
    }
    
    public Fase getFaseAtual() {
        return fases[faseAtual];
    }
    
    public boolean proximaFase() {
        if(faseAtual < fases.length - 1) {
            faseAtual++;
            return true;
        } else {
            return false;
        }
    }
}
