/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import Modelo.BichinhoVaiVemHorizontal;
import Modelo.BichinhoVaiVemVertical;
import Modelo.Bomba;
import Modelo.Cadeado;
import Modelo.Caveira;
import Modelo.Chave;
import Modelo.Coracao;
import Modelo.Espada;
import Modelo.Hero;
import Modelo.MonstroBarreira;
import Modelo.Parede;
import Modelo.ZigueZague;
import auxiliar.Posicao;
import java.util.ArrayList;

/**
 *
 * @author gabia
 */
public class Fase1 extends Fase{

    public Fase1() {
        super();
    }
    
    public ArrayList<Posicao> gerarParedesLabirinto() {
        ArrayList<Posicao> paredes = new ArrayList<>();

        // MATRIZ QUE DIZ ONDE TEM PAREDE
        int[][] matrizParedes = {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, 
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
        };
        
        for (int i = 0; i < matrizParedes.length; i++) {
            for (int j = 0; j < matrizParedes[i].length; j++) {
                if (matrizParedes[i][j] == 1) {
                    paredes.add(new Posicao(i,j));
                }
                
            }
        }

        return paredes;
    }

    public void desenhaParedes() {
        ArrayList<Posicao> posicoesParedes = gerarParedesLabirinto();
        
        for (Posicao pos : posicoesParedes) {
            Parede parede = new Parede("parede1.png");
            parede.setPosicao(pos.getLinha(), pos.getColuna());
            this.addPersonagem(parede);
        }
    }
    
    public void desenhaFase(){
        hero = new Hero("skoot.png");
        hero.setPosicao(3,2);
        
        this.addPersonagem(hero);
        this.atualizaCamera();
        Chave chave_arma = new Chave("espada.jpg");
        chave_arma.setPosicao(1,1);
                

        this.arma = new Espada("espada.jpg", hero, chave_arma);
        arma.setbVisivel(false);
        
        this.addPersonagem(arma);
        this.addPersonagem(chave_arma);  
        desenhaParedes();
        
        /*Cria faseAtual adiciona personagens*/
        
//        ZigueZague zz = new ZigueZague("seguidor.png", 5);
//        zz.setPosicao(9, 10);
//        this.addPersonagem(zz);

       /* BichinhoVaiVemHorizontal bBichinhoH = new BichinhoVaiVemHorizontal("roboPink.png", 5, 1);
        bBichinhoH.setPosicao(3, 3);
        this.addPersonagem(bBichinhoH);*/
        
        BichinhoVaiVemHorizontal guarda1 = new BichinhoVaiVemHorizontal("guarda.png", 3, 3);
        guarda1.setPosicao(9,1);
        guarda1.setbMortal(true);
        this.addPersonagem(guarda1);
        
        BichinhoVaiVemVertical guarda2 = new BichinhoVaiVemVertical ("guarda.png", 3, 3);
        guarda2.setPosicao(11,5);
        guarda2.setbMortal(true);
        this.addPersonagem(guarda2);
        
        BichinhoVaiVemHorizontal guarda3 = new BichinhoVaiVemHorizontal("guarda.png", 3, 3);
        guarda3.setPosicao(5,7);
        guarda3.setbMortal(true);
        this.addPersonagem(guarda3);
        
        BichinhoVaiVemHorizontal guarda4 = new BichinhoVaiVemHorizontal("guarda.png", 3,5);
        guarda4.setPosicao(8,12);
        guarda4.setbMortal(true);
        this.addPersonagem(guarda4);
        
        BichinhoVaiVemHorizontal guarda5 = new BichinhoVaiVemHorizontal("guarda.png", 3,4);
        guarda5.setPosicao(5,19);
        guarda5.setbMortal(true);
        this.addPersonagem(guarda5);
        
        BichinhoVaiVemHorizontal guarda6 = new BichinhoVaiVemHorizontal("guarda.png", 3,3);
        guarda6.setPosicao(10,25);
        guarda6.setbMortal(true);
        this.addPersonagem(guarda6);
        
        BichinhoVaiVemVertical guarda7 = new BichinhoVaiVemVertical ("guarda.png", 3, 6);
        guarda7.setPosicao(22,22);
        guarda7.setbMortal(true);
        this.addPersonagem(guarda7);
        
        BichinhoVaiVemVertical guarda8 = new BichinhoVaiVemVertical ("guarda.png", 5, 6);
        guarda8.setPosicao(22,18);
        guarda8.setbMortal(true);
        this.addPersonagem(guarda8);
        
        BichinhoVaiVemVertical guarda9 = new BichinhoVaiVemVertical ("guarda.png", 3, 6);
        guarda9.setPosicao(22,15);
        guarda9.setbMortal(true);
        this.addPersonagem(guarda9);
        
        BichinhoVaiVemVertical guarda10 = new BichinhoVaiVemVertical ("guarda.png", 4, 6);
        guarda10.setPosicao(22,12);
        guarda10.setbMortal(true);
        this.addPersonagem(guarda10);

        BichinhoVaiVemVertical guarda11 = new BichinhoVaiVemVertical ("guarda.png", 3, 6);
        guarda11.setPosicao(22,9);
        guarda11.setbMortal(true);
        this.addPersonagem(guarda11);
        
        BichinhoVaiVemVertical guarda12 = new BichinhoVaiVemVertical ("guarda.png", 4, 6);
        guarda12.setPosicao(22,6);
        guarda12.setbMortal(true);
        this.addPersonagem(guarda12);

        
        Coracao coracao_1 = new Coracao("coracao.png");
        coracao_1.setPosicao(18, 15);
        this.addPersonagem(coracao_1);
//        
//        Coracao coracao_2 = new Coracao("coracao.png");
//        coracao_2.setPosicao(5, 2);
//        this.addPersonagem(coracao_2);
//
//        Coracao coracao_3 = new Coracao("coracao.png");
//        coracao_3.setPosicao(5, 3);
//        this.addPersonagem(coracao_3);
       
//        Bomba bomba = new Bomba("bomba.png");
//        bomba.setPosicao(5,5);
//        this.addPersonagem(bomba);
        
        Chave chave_1 = new Chave("chave1.png");
        chave_1.setPosicao(2,11);
        this.addPersonagem(chave_1);
        
        Chave chave_2 = new Chave("chave1.png");
        chave_2.setPosicao(13,26);
        this.addPersonagem(chave_2);
        
        
        Cadeado cadeado = new Cadeado("cadeado1.png");
        cadeado.setPosicao(15,26);
        this.addPersonagem(cadeado);
        
        cadeado.adicionarChave(chave_1);
        cadeado.adicionarChave(chave_2);
       
        
        Chave chave_saida1 = new Chave("keycard.png");
        chave_saida1.setPosicao(12,18);
        this.addPersonagem(chave_saida1);
//        
        Chave chave_saida2 = new Chave("keycard.png");
        chave_saida2.setPosicao(18,18);
        this.addPersonagem(chave_saida2);
        
        Cadeado saida= new Cadeado("saida.png");
        saida.setPosicao(18,20);
        saida.setSaida(true);
        this.addPersonagem(saida);
        
//        saida.adicionarChave(chave_saida1);
//        saida.adicionarChave(chave_saida2);
        
        
       // chave_1.setColetada(true);
        //chave_2.setColetada(true);
        /*BichinhoVaiVemHorizontal bBichinhoH2 = new BichinhoVaiVemHorizontal("roboPink.png", 5 , 1);
        bBichinhoH2.setPosicao(6, 6);
        this.addPersonagem(bBichinhoH2);*/

//        Caveira bV = new Caveira("caveira.png");
//        bV.setPosicao(7, 1);
//        this.addPersonagem(bV);
//        
//        MonstroBarreira monstrobarreira = new MonstroBarreira("caveira.png", false);
//        monstrobarreira.setPosicao(5, 1);
//        monstrobarreira.setIsTransponivelArma(true);
//        this.addPersonagem(monstrobarreira);
        ////
       /*Perseguidor perseguidor = new Perseguidor("espada.jpg", 5);
        perseguidor.setPosicao(3,6);
        this.addPersonagem(perseguidor); */
       
        this.hud = new HUD(hero); 
    }
    
}
