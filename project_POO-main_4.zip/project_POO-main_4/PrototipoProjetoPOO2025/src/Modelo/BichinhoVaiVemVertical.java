package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenho;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.io.IOException;
import java.io.Serializable;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author thiag
 */
public class BichinhoVaiVemVertical extends Monstro implements Serializable{
    private boolean bDown;
    private int iContaIntervalos;
    private int intervaloMovimento;
 
    private int passosMaximos;    // Quantidade de passos para cada lado
    private int passosDados;      // Quantos passos já andou na direção atual
    
    public BichinhoVaiVemVertical(String sNomeImagePNG, int intervaloMovimento, int passosMaximos) {
        super(sNomeImagePNG, false);
        this.bDown = true;
        this.iContaIntervalos = 0;
        this.intervaloMovimento = intervaloMovimento;
        this.passosMaximos = passosMaximos;
    }
    public void autoDesenho() {
        super.autoDesenho();

        iContaIntervalos++;
        if (iContaIntervalos < intervaloMovimento)
            return;

        iContaIntervalos = 0;

        boolean moveu;
        if (bDown) {
            moveu = this.moveDown();
        } else {
            moveu = this.moveUp();
        }

        if (moveu) {
            passosDados++;
            if (passosDados >= passosMaximos) {
                passosDados = 0;
                bDown = !bDown; // Inverte direção após X passos
            }
        } else {
            // Se bateu em obstáculo, muda a direção mesmo que não tenha terminado os passos
            passosDados = 0;
            bDown = !bDown;
        }
    }
}
