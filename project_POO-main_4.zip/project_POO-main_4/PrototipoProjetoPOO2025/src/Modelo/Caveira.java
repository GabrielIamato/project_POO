package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenho;
import Controler.Tela;
import java.awt.Graphics;
import java.io.Serializable;

public class Caveira extends Monstro implements Serializable{
    private int iContaIntervalos;
    private int direcaoFogo; // se 1, vai pra direita; se 2, vai pra esquerda
    
    public Caveira(String sNomeImagePNG, int direcaoFogo) {
        super(sNomeImagePNG, true);
        this.bTransponivel = false;
        this.iContaIntervalos = 0;
        this.direcaoFogo = direcaoFogo;
    }

    public void autoDesenho() {
        super.autoDesenho();

        this.iContaIntervalos++;
        if(this.iContaIntervalos == Consts.TIMER){
            this.iContaIntervalos = 0;
            
              Fogo f;
              if (direcaoFogo == 1) {
                  f = new Fogo("fire_direita.png", 1);
                  f.setPosicao(pPosicao.getLinha(),pPosicao.getColuna() + 1);
              } else {
                  f = new Fogo("fire_esquerda.png", 2);
                  f.setPosicao(pPosicao.getLinha(),pPosicao.getColuna() - 1);
              }
              
              Desenho.acessoATelaDoJogo().getFaseAtual().addPersonagem(f);
        }
    }    
}
