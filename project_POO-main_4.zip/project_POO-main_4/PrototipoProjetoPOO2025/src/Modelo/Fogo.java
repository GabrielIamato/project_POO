package Modelo;

import Auxiliar.Desenho;
import Controler.Tela;
import java.awt.Graphics;
import java.io.Serializable;

public class Fogo extends Personagem implements Serializable{
    
    private int direcao;
    
    public Fogo(String sNomeImagePNG, int direcao) {
        super(sNomeImagePNG);
        this.bMortal = true;
        this.direcao = direcao;
    }

    @Override
    public void autoDesenho() {
        super.autoDesenho();
        
        boolean moveu;
        if (direcao == 1) {
            moveu = this.moveRight();
        } else {
            moveu = this.moveLeft();
        }
        
        if(!moveu)
            Desenho.acessoATelaDoJogo().getFaseAtual().removePersonagem(this);
    }
    
}
