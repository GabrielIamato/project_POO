package Controler;

import Modelo.BichinhoVaiVemHorizontal;
import Modelo.Bomba;
import Modelo.Cadeado;
import Modelo.Caveira;
import Modelo.Chave;
import Modelo.Coracao;
import Modelo.Espada;
import Modelo.Hero;
import Modelo.MonstroBarreira;
import Modelo.Parede;
import Modelo.ZigueZague;
import auxiliar.Posicao;
import java.util.ArrayList;
import java.io.Serializable;

/**
 *
 * @author thiag
 */
public class Fase2 extends Fase implements Serializable {
    
    public Fase2() {
        super();
    }
    
    public ArrayList<Posicao> gerarParedesLabirinto() {
        ArrayList<Posicao> paredes = new ArrayList<>();

        // Cria paredes nas bordas
        int[][] matrizParedes = {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
           };

        
        for (int i = 0; i < matrizParedes.length; i++) {
            for (int j = 0; j < matrizParedes[i].length; j++) {
                if (matrizParedes[i][j] == 1) {
                    paredes.add(new Posicao(i,j));
                }
                
            }
        }

        return paredes;
    }

    public void desenhaParedes() {
        ArrayList<Posicao> posicoesParedes = gerarParedesLabirinto();
        
        for (Posicao pos : posicoesParedes) {
            Parede parede = new Parede("parede2.png");
            parede.setPosicao(pos.getLinha(), pos.getColuna());
            this.addPersonagem(parede);
        }
    }
    
    public void desenhaFase(){
        hero = new Hero("skoot.png");
        hero.setPosicao(3, 6);
        
        this.addPersonagem(hero);
        this.atualizaCamera();
        Chave chave_arma = new Chave("espada.jpg");
        chave_arma.setPosicao(1,1);
                

        this.arma = new Espada("espada.jpg", hero, chave_arma);
        arma.setbVisivel(false);
        
        this.addPersonagem(arma);
        this.addPersonagem(chave_arma);  
        desenhaParedes();
        
        /*Cria faseAtual adiciona personagens*/
        
        Caveira torreta1 = new Caveira("torreta_direita.png", 1);
        torreta1.setPosicao(8, 3);
        this.addPersonagem(torreta1);
        
        Caveira torreta2 = new Caveira("torreta_esquerda.png", 2);
        torreta2.setPosicao(12, 27);
        this.addPersonagem(torreta2);
        
        Caveira torreta3 = new Caveira("torreta_direita.png", 1);
        torreta3.setPosicao(16,2);
        this.addPersonagem(torreta3);
        
        Caveira torreta4 = new Caveira("torreta_esquerda.png", 2);
        torreta4.setPosicao(20, 27);
        this.addPersonagem(torreta4);

        // PRIMEIRA CHAVE - CADEADO
        Chave chave1 = new Chave("chave1.png");
        chave1.setPosicao(7,16);
        this.addPersonagem(chave1);
        
        Cadeado cadeado1 = new Cadeado("cadeado1.png");
        cadeado1.setPosicao(10,25);
        this.addPersonagem(cadeado1);
        
        cadeado1.adicionarChave(chave1);
        
        // SEGUNDA CHAVE - CADEADO
        Chave chave2 = new Chave("chave2.png");
        chave2.setPosicao(11,12);
        this.addPersonagem(chave2);
        
        Cadeado cadeado2 = new Cadeado("cadeado2.png");
        cadeado2.setPosicao(14,4);
        this.addPersonagem(cadeado2);
        
        cadeado2.adicionarChave(chave2);
        
        // TERCEIRA CHAVE- CADEADO
        Chave chave3 = new Chave("chave3.png");
        chave3.setPosicao(17, 17);
        this.addPersonagem(chave3);
        
        Cadeado cadeado3 = new Cadeado("cadeado3.png");
        cadeado3.setPosicao(18,25);
        this.addPersonagem(cadeado3);
        
        cadeado3.adicionarChave(chave3);
        
        // QUARTA CHAVE - CADEADO;
        Chave chave4 = new Chave("chave4.png");
        chave4.setPosicao(19,11);
        this.addPersonagem(chave4);
        
        Cadeado cadeado4 = new Cadeado("cadeado4.png");
        cadeado4.setPosicao(22,4);
        this.addPersonagem(cadeado4);
        
        cadeado4.adicionarChave(chave4);
        
        // SAIDA E KEYCARDS
        Chave keycard1 = new Chave("keycard.png");
        keycard1.setPosicao(12,1);
        this.addPersonagem(keycard1);
        
        Chave keycard2 = new Chave("keycard.png");
        keycard2.setPosicao(15,12);
        this.addPersonagem(keycard2);
        
        Chave keycard3 = new Chave("keycard.png");
        keycard3.setPosicao(20,1);
        this.addPersonagem(keycard3);
        
        Cadeado saida= new Cadeado("saída.png");
        saida.setPosicao(26,4);
        saida.setSaida(true);
        this.addPersonagem(saida);
        
        saida.adicionarChave(keycard1);
        saida.adicionarChave(keycard2);
        saida.adicionarChave(keycard3);
                
        Coracao vida1 = new Coracao("coracao.png");
        vida1.setPosicao(13, 16);
        this.addPersonagem(vida1);
        
        Coracao vida2 = new Coracao("coracao.png");
        vida2.setPosicao(19,25);
        this.addPersonagem(vida2);

        
       // chave_1.setColetada(true);
        //chave_2.setColetada(true);
        /*BichinhoVaiVemHorizontal bBichinhoH2 = new BichinhoVaiVemHorizontal("roboPink.png", 5 , 1);
        bBichinhoH2.setPosicao(6, 6);
        this.addPersonagem(bBichinhoH2);*/
        
//        MonstroBarreira monstrobarreira = new MonstroBarreira("caveira.png", false);
//        monstrobarreira.setPosicao(5, 1);
//        monstrobarreira.setIsTransponivelArma(true);
//        this.addPersonagem(monstrobarreira);
        ////
       /*Perseguidor perseguidor = new Perseguidor("espada.jpg", 5);
        perseguidor.setPosicao(3,6);
        this.addPersonagem(perseguidor); */
       
        this.hud = new HUD(hero); 
    }
}
