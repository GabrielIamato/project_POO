/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import Modelo.BichinhoVaiVemHorizontal;
import Modelo.BichinhoVaiVemVertical;
import Modelo.Cadeado;
import Modelo.Caveira;
import Modelo.Chave;
import Modelo.Coracao;
import Modelo.Espada;
import Modelo.Hero;
import Modelo.MonstroBarreira;
import Modelo.Parede;
import Modelo.Perseguidor;
import Modelo.ZigueZague;
import auxiliar.Posicao;
import java.util.ArrayList;
import java.io.Serializable;

/**
 *
 * @author thiag
 */
public class Fase4 extends Fase implements Serializable {
    
    public Fase4() {
        super();
    }
    
    public ArrayList<Posicao> gerarParedesLabirinto() {
        ArrayList<Posicao> paredes = new ArrayList<>();

        // MATRIZ QUE DIZ ONDE TEM PAREDE
        int[][] matrizParedes = {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, 
            {1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, 
            {1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, 
            {1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, 
            {1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, 
            {1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, 
            {1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, 
            {1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, 
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, 
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, 
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, 
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, 
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1}, 
            {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1}, 
            {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1}, 
            {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1}, 
            {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1}, 
            {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
        };
        
        for (int i = 0; i < matrizParedes.length; i++) {
            for (int j = 0; j < matrizParedes[i].length; j++) {
                if (matrizParedes[i][j] == 1) {
                    paredes.add(new Posicao(i,j));
                }
                
            }
        }

        return paredes;
    }

    public void desenhaParedes() {
        ArrayList<Posicao> posicoesParedes = gerarParedesLabirinto();
        
        for (Posicao pos : posicoesParedes) {
            Parede parede = new Parede("parede4.png");
            parede.setPosicao(pos.getLinha(), pos.getColuna());
            this.addPersonagem(parede);
        }
    }
    
    public void desenhaFase(){
        hero = new Hero("skoot.png");
        hero.setPosicao(5, 24);
        
        this.addPersonagem(hero);
        this.atualizaCamera();
        Chave chave_arma = new Chave("espada.png");
        chave_arma.setPosicao(12, 5);   

        this.arma = new Espada("espada.png", hero, chave_arma);
        arma.setbVisivel(false);
        
        this.addPersonagem(arma);
        this.addPersonagem(chave_arma);  
        desenhaParedes();
        
        /*Cria faseAtual adiciona personagens*/
        
        Perseguidor perseguidor = new Perseguidor("seguidor.png",3);
        perseguidor.setPosicao(27,27);
        this.addPersonagem(perseguidor);
        
        Caveira torreta1 = new Caveira("torreta_direita.png", 1);
        torreta1.setPosicao(25, 8);
        this.addPersonagem(torreta1);
        
        Caveira torreta2 = new Caveira("torreta_direita.png", 1);
        torreta2.setPosicao(23, 8);
        this.addPersonagem(torreta2);
        
        Caveira torreta3 = new Caveira("torreta_direita.png", 1);
        torreta3.setPosicao(24, 4);
        this.addPersonagem(torreta3);
       
        BichinhoVaiVemHorizontal guarda1 = new BichinhoVaiVemHorizontal("guarda.png", 3, 1);
        guarda1.setPosicao(12, 24);
        guarda1.setbMortal(true);
        this.addPersonagem(guarda1);
        
        BichinhoVaiVemHorizontal guarda2 = new BichinhoVaiVemHorizontal("guarda.png", 5, 1);
        guarda2.setPosicao(14, 24);
        guarda2.setbMortal(true);
        this.addPersonagem(guarda2);
        
        BichinhoVaiVemHorizontal guarda3 = new BichinhoVaiVemHorizontal("guarda.png", 3, 1);
        guarda3.setPosicao(16, 24);
        guarda3.setbMortal(true);
        this.addPersonagem(guarda3);
        
        BichinhoVaiVemHorizontal guarda4 = new BichinhoVaiVemHorizontal("guarda.png", 6, 3);
        guarda4.setPosicao(20, 4);
        guarda4.setbMortal(true);
        this.addPersonagem(guarda4);
        
        BichinhoVaiVemHorizontal guarda5 = new BichinhoVaiVemHorizontal("guarda.png", 3, 3);
        guarda5.setPosicao(19, 4);
        guarda5.setbMortal(true);
        this.addPersonagem(guarda5);

        BichinhoVaiVemHorizontal guarda6 = new BichinhoVaiVemHorizontal("guarda.png", 5, 3);
        guarda6.setPosicao(18, 4);
        guarda6.setbMortal(true);
        this.addPersonagem(guarda6);
        
        ZigueZague guarda7 = new ZigueZague("guarda.png", 4);
        guarda7.setPosicao(14, 12);
        this.addPersonagem(guarda7);
        
        // VIDA
        Coracao vida1 = new Coracao("coracao.png");
        vida1.setPosicao(22, 23);
        this.addPersonagem(vida1);
        
        // CADEADOS E CHAVE
        
        Chave chave1 = new Chave("chave5.png");
        chave1.setPosicao(24,19);
        this.addPersonagem(chave1);
        
        Cadeado cadeado1 = new Cadeado ("cadeado5.png");
        cadeado1.setPosicao(25, 16);
        this.addPersonagem(cadeado1);
        
        Cadeado cadeado2 = new Cadeado ("cadeado5.png");
        cadeado2.setPosicao(24, 16);
        this.addPersonagem(cadeado2);
        
        Cadeado cadeado3 = new Cadeado ("cadeado5.png");
        cadeado3.setPosicao(23, 16);
        this.addPersonagem(cadeado3);
        
        Cadeado cadeado4 = new Cadeado ("cadeado5.png");
        cadeado4.setPosicao(26, 27);
        this.addPersonagem(cadeado4);
        
        Cadeado cadeado5 = new Cadeado ("cadeado5.png");
        cadeado5.setPosicao(26, 26);
        this.addPersonagem(cadeado5);
        
        Cadeado cadeado6 = new Cadeado ("cadeado5.png");
        cadeado6.setPosicao(27, 26);
        this.addPersonagem(cadeado6);
        
        cadeado1.adicionarChave(chave1);
        cadeado2.adicionarChave(chave1);
        cadeado3.adicionarChave(chave1);
        cadeado4.adicionarChave(chave1);
        cadeado5.adicionarChave(chave1);
        cadeado6.adicionarChave(chave1);
        
        
        
        // SAIDA
        
                Chave chave_saida1 = new Chave("keycard.png");
        chave_saida1.setPosicao(13,14);
        this.addPersonagem(chave_saida1);

       
        Chave chave_saida2 = new Chave("keycard.png");
        chave_saida2.setPosicao(22,2);
        this.addPersonagem(chave_saida2);
        
        Cadeado saida= new Cadeado("saida.png");
        saida.setPosicao(5,14);
        saida.setSaida(true);
        this.addPersonagem(saida);
        
        saida.adicionarChave(chave_saida1);
        saida.adicionarChave(chave_saida2);
      
        // BARREIRAS
        
        MonstroBarreira monstrobarreira1 = new MonstroBarreira("parede4_quebrada.png", false);
        monstrobarreira1.setPosicao(12, 10);
        monstrobarreira1.setIsTransponivelArma(true);
        this.addPersonagem(monstrobarreira1);
        
        MonstroBarreira monstrobarreira2 = new MonstroBarreira("parede4_quebrada.png", false);
        monstrobarreira2.setPosicao(13, 10);
        monstrobarreira2.setIsTransponivelArma(true);
        this.addPersonagem(monstrobarreira2);
        
        MonstroBarreira monstrobarreira3 = new MonstroBarreira("parede4_quebrada.png", false);
        monstrobarreira3.setPosicao(14, 10);
        monstrobarreira3.setIsTransponivelArma(true);
        this.addPersonagem(monstrobarreira3);
        
        MonstroBarreira monstrobarreira4 = new MonstroBarreira("parede4_quebrada.png", false);
        monstrobarreira4.setPosicao(10, 13);
        monstrobarreira4.setIsTransponivelArma(true);
        this.addPersonagem(monstrobarreira4);
        
        MonstroBarreira monstrobarreira5 = new MonstroBarreira("parede4_quebrada.png", false);
        monstrobarreira5.setPosicao(10, 14);
        monstrobarreira5.setIsTransponivelArma(true);
        this.addPersonagem(monstrobarreira5);
        
        MonstroBarreira monstrobarreira6 = new MonstroBarreira("parede4_quebrada.png", false);
        monstrobarreira6.setPosicao(10, 15);
        monstrobarreira6.setIsTransponivelArma(true);
        this.addPersonagem(monstrobarreira6);


        
        this.hud = new HUD(hero); 
    }
    
}
