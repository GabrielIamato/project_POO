/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import Modelo.BichinhoVaiVemHorizontal;
import Modelo.BichinhoVaiVemVertical;
import Modelo.Bomba;
import Modelo.Cadeado;
import Modelo.Caveira;
import Modelo.Chave;
import Modelo.Coracao;
import Modelo.Espada;
import Modelo.Hero;
import Modelo.MonstroBarreira;
import Modelo.Parede;
import Modelo.Perseguidor;
import Modelo.ZigueZague;
import auxiliar.Posicao;
import java.util.ArrayList;
import java.io.Serializable;

/**
 *
 * @author thiag
 */
public class Fase5 extends Fase implements Serializable {
    
    public Fase5() {
        super();
    }
    
    public ArrayList<Posicao> gerarParedesLabirinto() {
        ArrayList<Posicao> paredes = new ArrayList<>();

        // MATRIZ QUE DIZ ONDE TEM PAREDE
        int[][] matrizParedes = {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
        };
        
        for (int i = 0; i < matrizParedes.length; i++) {
            for (int j = 0; j < matrizParedes[i].length; j++) {
                if (matrizParedes[i][j] == 1) {
                    paredes.add(new Posicao(i,j));
                }
                
            }
        }

        return paredes;
    }

    public void desenhaParedes() {
        ArrayList<Posicao> posicoesParedes = gerarParedesLabirinto();
        
        for (Posicao pos : posicoesParedes) {
            Parede parede = new Parede("parede5.png");
            parede.setPosicao(pos.getLinha(), pos.getColuna());
            this.addPersonagem(parede);
        }
    }
    
    public void desenhaFase(){
        hero = new Hero("skoot.png");
        hero.setPosicao(5,14);
        
        this.addPersonagem(hero);
        this.atualizaCamera();
        Chave chave_arma = new Chave("espada.png");
        chave_arma.setPosicao(5, 15);   

        this.arma = new Espada("espada.png", hero, chave_arma);
        arma.setbVisivel(false);
        
        this.addPersonagem(arma);
        this.addPersonagem(chave_arma);  
        desenhaParedes();
        
        /*Cria faseAtual adiciona personagens*/
        
        Perseguidor p1 = new Perseguidor("seguidor.png", 5);
        p1.setPosicao(28, 10);
        p1.setbMortal(true);
        this.addPersonagem(p1);
        
        Perseguidor p2 = new Perseguidor("seguidor.png", 4);
        p2.setPosicao(5, 20);
        p2.setbMortal(true);
        this.addPersonagem(p2);
        
        Perseguidor p3 = new Perseguidor("seguidor.png", 5);
        p3.setPosicao(28, 14);
        p3.setbMortal(true);
        this.addPersonagem(p3);
        
        Perseguidor p4 = new Perseguidor("seguidor.png", 5);
        p4.setPosicao(28, 19);
        p4.setbMortal(true);
        this.addPersonagem(p4);
        
        Perseguidor p5 = new Perseguidor("seguidor.png", 5);
        p5.setPosicao(5, 9);
        p5.setbMortal(true);
        this.addPersonagem(p5);
        
        ZigueZague z1 = new ZigueZague("guarda.png", 3);
        z1.setPosicao(1, 14);
        z1.setbMortal(true);
        this.addPersonagem(z1);
        
        ZigueZague z2 = new ZigueZague("guarda.png", 2);
        z2.setPosicao(18, 14);
        z2.setbMortal(true);
        this.addPersonagem(z2);
        
        ZigueZague z3 = new ZigueZague("guarda.png", 2);
        z3.setPosicao(24, 17);
        z3.setbMortal(true);
        this.addPersonagem(z3);
        
        Caveira t1 = new Caveira ("torreta_direita.png", 1);
        t1.setPosicao(14, 6);
        this.addPersonagem(t1);
        
        Caveira t2 = new Caveira ("torreta_direita.png", 1);
        t2.setPosicao(22, 6);
        this.addPersonagem(t2);
        
        Caveira t3 = new Caveira ("torreta_esquerda.png", 2);
        t3.setPosicao(22, 23);
        this.addPersonagem(t3);
        
        Caveira t4 = new Caveira ("torreta_esquerda.png", 2);
        t4.setPosicao(14, 23);
        this.addPersonagem(t4);

        Bomba b1 = new Bomba("bomba.png");
        b1.setPosicao(11, 16);
        this.addPersonagem(b1);
        
        Bomba b2 = new Bomba("bomba.png");
        b2.setPosicao(18, 14);
        this.addPersonagem(b2);

        Bomba b3 = new Bomba("bomba.png");
        b3.setPosicao(24, 16);
        this.addPersonagem(b3);

        
        // VIDA
        Coracao vida1 = new Coracao("coracao.png");
        vida1.setPosicao(25, 22);
        this.addPersonagem(vida1);
        
        Coracao vida2 = new Coracao("coracao.png");
        vida2.setPosicao(18, 22);
        this.addPersonagem(vida2);
        
        Coracao vida3 = new Coracao("coracao.png");
        vida3.setPosicao(18, 7);
        this.addPersonagem(vida3);
        
        // CADEADOS E CHAVE
        
        Chave chave1 = new Chave("chave1.png");
        chave1.setPosicao(10,5);
        this.addPersonagem(chave1);
        
        Cadeado cadeado1 = new Cadeado ("cadeado1.png");
        cadeado1.setPosicao(25, 21);
        this.addPersonagem(cadeado1);
        
        Cadeado cadeado11 = new Cadeado ("cadeado1.png");
        cadeado11.setPosicao(27, 11);
        this.addPersonagem(cadeado11);
        
        Cadeado cadeado12 = new Cadeado ("cadeado1.png");
        cadeado12.setPosicao(27, 10);
        this.addPersonagem(cadeado12);
        
        Cadeado cadeado13 = new Cadeado ("cadeado1.png");
        cadeado13.setPosicao(27, 9);
        this.addPersonagem(cadeado13);
        
        cadeado1.adicionarChave(chave1);
        cadeado11.adicionarChave(chave1);
        cadeado12.adicionarChave(chave1);
        cadeado13.adicionarChave(chave1);
                
        Chave chave2 = new Chave("chave2.png");
        chave2.setPosicao(26,24);
        this.addPersonagem(chave2);
        
        Cadeado cadeado2 = new Cadeado ("cadeado2.png");
        cadeado2.setPosicao(10, 21);
        this.addPersonagem(cadeado2);
        
        Cadeado cadeado21 = new Cadeado ("cadeado2.png");
        cadeado21.setPosicao(7, 20);
        this.addPersonagem(cadeado21);
        
        Cadeado cadeado22 = new Cadeado ("cadeado2.png");
        cadeado22.setPosicao(7, 19);
        this.addPersonagem(cadeado22);

        cadeado2.adicionarChave(chave2);
        cadeado21.adicionarChave(chave2);
        cadeado22.adicionarChave(chave2);
        
        Chave chave3 = new Chave("chave3.png");
        chave3.setPosicao(10,24);
        this.addPersonagem(chave3);
        
        Cadeado cadeado3 = new Cadeado ("cadeado3.png");
        cadeado3.setPosicao(18, 8);
        this.addPersonagem(cadeado3);
        
        Cadeado cadeado31 = new Cadeado ("cadeado3.png");
        cadeado31.setPosicao(27, 16);
        this.addPersonagem(cadeado31);
        
        Cadeado cadeado32 = new Cadeado ("cadeado3.png");
        cadeado32.setPosicao(27, 15);
        this.addPersonagem(cadeado32);
        
        Cadeado cadeado33 = new Cadeado ("cadeado3.png");
        cadeado33.setPosicao(27, 14);
        this.addPersonagem(cadeado33);
        
        Cadeado cadeado34 = new Cadeado ("cadeado3.png");
        cadeado34.setPosicao(27, 13);
        this.addPersonagem(cadeado34);
        
        cadeado3.adicionarChave(chave3);
        cadeado31.adicionarChave(chave3);
        cadeado32.adicionarChave(chave3);
        cadeado33.adicionarChave(chave3);
        cadeado34.adicionarChave(chave3);
        
        Chave chave4 = new Chave("chave4.png");
        chave4.setPosicao(18,5);
        this.addPersonagem(chave4);
        
        Cadeado cadeado4 = new Cadeado ("cadeado4.png");
        cadeado4.setPosicao(25, 8);
        this.addPersonagem(cadeado4);
        
        Cadeado cadeado41 = new Cadeado ("cadeado4.png");
        cadeado41.setPosicao(27, 20);
        this.addPersonagem(cadeado41);
        
        Cadeado cadeado42 = new Cadeado ("cadeado4.png");
        cadeado42.setPosicao(27, 19);
        this.addPersonagem(cadeado42);
        
        Cadeado cadeado43 = new Cadeado ("cadeado4.png");
        cadeado43.setPosicao(27, 18);
        this.addPersonagem(cadeado43);

        
        cadeado4.adicionarChave(chave4);
        cadeado41.adicionarChave(chave4);
        cadeado42.adicionarChave(chave4);
        cadeado43.adicionarChave(chave4);
        
        Chave chave5 = new Chave("chave5.png");
        chave5.setPosicao(26,5);
        this.addPersonagem(chave5);
        
        Cadeado cadeado5 = new Cadeado ("cadeado5.png");
        cadeado5.setPosicao(18, 21);
        this.addPersonagem(cadeado5);
        
        Cadeado cadeado51 = new Cadeado ("cadeado5.png");
        cadeado51.setPosicao(7, 9);
        this.addPersonagem(cadeado51);
        
        Cadeado cadeado52 = new Cadeado ("cadeado5.png");
        cadeado52.setPosicao(7, 10);
        this.addPersonagem(cadeado52);
        
        cadeado5.adicionarChave(chave5);
        cadeado51.adicionarChave(chave5);
        cadeado52.adicionarChave(chave5);
        
        Chave chave6 = new Chave("chave6.png");
        chave6.setPosicao(18,24);
        this.addPersonagem(chave6);
        
        Cadeado cadeado61 = new Cadeado ("cadeado6.png");
        cadeado61.setPosicao(3, 14);
        this.addPersonagem(cadeado61);
        
        Cadeado cadeado62 = new Cadeado ("cadeado6.png");
        cadeado62.setPosicao(3, 15);
        this.addPersonagem(cadeado62);
        
        cadeado61.adicionarChave(chave6);
        cadeado62.adicionarChave(chave6);

        
        // SAIDA
        
        Chave chave_saida1 = new Chave("keycard.png");
        chave_saida1.setPosicao(10,6);
        this.addPersonagem(chave_saida1);

        Chave chave_saida2 = new Chave("keycard.png");
        chave_saida2.setPosicao(26,23);
        this.addPersonagem(chave_saida2);
        
        Chave chave_saida3 = new Chave("keycard.png");
        chave_saida3.setPosicao(10,23);
        this.addPersonagem(chave_saida3);
        
        Chave chave_saida4 = new Chave("keycard.png");
        chave_saida4.setPosicao(18,6);
        this.addPersonagem(chave_saida4);
        
        Chave chave_saida5 = new Chave("keycard.png");
        chave_saida5.setPosicao(26,6);
        this.addPersonagem(chave_saida5);
        
        Chave chave_saida6 = new Chave("keycard.png");
        chave_saida6.setPosicao(18,23);
        this.addPersonagem(chave_saida6);
        
        Cadeado saida= new Cadeado("saida.png");
        saida.setPosicao(1,15);
        saida.setSaida(true);
        this.addPersonagem(saida);
        
        saida.adicionarChave(chave_saida1);
        saida.adicionarChave(chave_saida2);
        saida.adicionarChave(chave_saida3);
        saida.adicionarChave(chave_saida4);
        saida.adicionarChave(chave_saida5);
        saida.adicionarChave(chave_saida6);
      
        // BARREIRAS
        
        MonstroBarreira monstrobarreira1 = new MonstroBarreira("parede5_quebrada.png", false);
        monstrobarreira1.setPosicao(7, 14);
        monstrobarreira1.setIsTransponivelArma(true);
        this.addPersonagem(monstrobarreira1);
        
        MonstroBarreira monstrobarreira2 = new MonstroBarreira("parede5_quebrada.png", false);
        monstrobarreira2.setPosicao(7, 15);
        monstrobarreira2.setIsTransponivelArma(true);
        this.addPersonagem(monstrobarreira2);
        
        MonstroBarreira monstrobarreira3 = new MonstroBarreira("parede5_quebrada.png", false);
        monstrobarreira3.setPosicao(10, 8);
        monstrobarreira3.setIsTransponivelArma(true);
        this.addPersonagem(monstrobarreira3);
        
//        MonstroBarreira monstrobarreira4 = new MonstroBarreira("parede4_quebrada.png", false);
//        monstrobarreira4.setPosicao(10, 13);
//        monstrobarreira4.setIsTransponivelArma(true);
//        this.addPersonagem(monstrobarreira4);
//        
//        MonstroBarreira monstrobarreira5 = new MonstroBarreira("parede4_quebrada.png", false);
//        monstrobarreira5.setPosicao(10, 14);
//        monstrobarreira5.setIsTransponivelArma(true);
//        this.addPersonagem(monstrobarreira5);
//        
//        MonstroBarreira monstrobarreira6 = new MonstroBarreira("parede4_quebrada.png", false);
//        monstrobarreira6.setPosicao(10, 15);
//        monstrobarreira6.setIsTransponivelArma(true);
//        this.addPersonagem(monstrobarreira6);


        
        this.hud = new HUD(hero); 
    }
    
}

